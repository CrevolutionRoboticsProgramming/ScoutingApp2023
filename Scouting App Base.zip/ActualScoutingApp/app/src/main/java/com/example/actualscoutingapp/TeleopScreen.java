package com.example.actualscoutingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class TeleopScreen extends AppCompatActivity {

    //creating variables for everything on the .xml file
    ImageButton autonBtn2, teleopBtn2, endgameBtn2, qrcodeBtn2;
    TextView autonTitleTxt2, teleopTitleTxt2, endgameTitleTxt2, qrcodeTitleTxt2, teleopTitleTxt, matchNumTitle2, teamNumTitle2, teleopMatchInfoBack;
    ImageView teleopScreenBackground, teleopHomeBtnPic, teleopTitleUnderline, matchNumBack2, teamNumBack2;
    EditText matchNumInput2, teamNumInput2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teleop_screen);


        //get rid of action bar when running the app
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        //matching the variables created to the ids on the .xml files
        autonBtn2 = findViewById(R.id.autonUnclicked2);
        teleopBtn2 = findViewById(R.id.teleopClicked2);
        endgameBtn2 = findViewById(R.id.endgameUnclicked2);
        qrcodeBtn2 = findViewById(R.id.qrcodeUnclicked2);

        autonTitleTxt2 = findViewById(R.id.autonTitleText2);
        teleopTitleTxt2 = findViewById(R.id.teleopTitleText2);
        endgameTitleTxt2 = findViewById(R.id.endgameTitleText2);
        qrcodeTitleTxt2 = findViewById(R.id.qrcodeTitleText2);
        teleopTitleTxt = findViewById(R.id.teleopScreenTitle);
        matchNumTitle2 = findViewById(R.id.teleopMatchNumberTitle);
        teamNumTitle2 = findViewById(R.id.teleopTeamNumberTitle);
        teleopMatchInfoBack = findViewById(R.id.teleopInputBack);

        teleopScreenBackground = findViewById(R.id.teleopBackground);
        teleopHomeBtnPic = findViewById(R.id.teleopHome);
        teleopTitleUnderline = findViewById(R.id.teleopScreenTitleUnderline);
        matchNumBack2 = findViewById(R.id.teleopMatchNumBack);
        teamNumBack2 = findViewById(R.id.teleopTeamNumBack);

        matchNumInput2 = findViewById(R.id.teleopMatchNumInput);
        teamNumInput2 = findViewById(R.id.teleopTeamNumInput);


        teleopHomeBtnPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToHomeScreen = new Intent(TeleopScreen.this, MainActivity.class);
                startActivity(goToHomeScreen);
            }
        });

        autonBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToAutonScreen = new Intent(TeleopScreen.this, AutonScreen.class);
                startActivity(goToAutonScreen);
            }
        });

        endgameBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToEndgameScreen = new Intent(TeleopScreen.this, EndScreen.class);
                startActivity(goToEndgameScreen);
            }
        });

        qrcodeBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToQrcodeScreen = new Intent(TeleopScreen.this, QRCommentsScreen.class);
                startActivity(goToQrcodeScreen);
            }
        });
    }
}