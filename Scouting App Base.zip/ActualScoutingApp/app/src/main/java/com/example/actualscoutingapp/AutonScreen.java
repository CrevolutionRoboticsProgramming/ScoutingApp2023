package com.example.actualscoutingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class AutonScreen extends AppCompatActivity {

    //creating variables for everything on the .xml file
    ImageButton autonBtn1, teleopBtn1, endgameBtn1, qrcodeBtn1;
    TextView autonTitleTxt1, teleopTitleTxt1, endgameTitleTxt1, qrcodeTitleTxt1, autonTitleTxt, matchNumTitle1, teamNumTitle1, autonMatchInfoBack;
    ImageView autonScreenBackground, autonHomeBtnPic, autonTitleUnderline, matchNumBack1, teamNumBack1;
    EditText matchNumInput1, teamNumInput1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auton_screen);


        //get rid of action bar when running the app
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        //matching the variables created to the ids on the .xml files
        autonBtn1 = findViewById(R.id.autonClicked);
        teleopBtn1 = findViewById(R.id.teleopUnclicked);
        endgameBtn1 = findViewById(R.id.endgameUnclicked);
        qrcodeBtn1 = findViewById(R.id.qrcodeUnclicked);

        autonTitleTxt1 = findViewById(R.id.autonTitleText);
        teleopTitleTxt1 = findViewById(R.id.teleopTitleText);
        endgameTitleTxt1 = findViewById(R.id.endgameTitleText);
        qrcodeTitleTxt1 = findViewById(R.id.qrcodeTitleText);
        autonTitleTxt = findViewById(R.id.autonScreenTitle);
        matchNumTitle1 = findViewById(R.id.autonMatchNumberTitle);
        teamNumTitle1 = findViewById(R.id.autonTeamNumberTitle);
        autonMatchInfoBack = findViewById(R.id.autonInputBack);

        autonScreenBackground = findViewById(R.id.autonBackground);
        autonHomeBtnPic = findViewById(R.id.autonHome);
        autonTitleUnderline = findViewById(R.id.autonScreenTitleUnderline);
        matchNumBack1 = findViewById(R.id.autonMatchNumBack);
        teamNumBack1 = findViewById(R.id.autonTeamNumBack);

        matchNumInput1 = findViewById(R.id.autonMatchNumInput);
        teamNumInput1 = findViewById(R.id.autonTeamNumInput);



        autonHomeBtnPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToHomeScreen = new Intent(AutonScreen.this, MainActivity.class);
                startActivity(goToHomeScreen);
            }
        });

        teleopBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToTeleopScreen = new Intent(AutonScreen.this, TeleopScreen.class);
                startActivity(goToTeleopScreen);
            }
        });

        endgameBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToEndgameScreen = new Intent(AutonScreen.this, EndScreen.class);
                startActivity(goToEndgameScreen);
            }
        });

        qrcodeBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToQrcodeScreen = new Intent(AutonScreen.this, QRCommentsScreen.class);
                startActivity(goToQrcodeScreen);
            }
        });
    }
}


